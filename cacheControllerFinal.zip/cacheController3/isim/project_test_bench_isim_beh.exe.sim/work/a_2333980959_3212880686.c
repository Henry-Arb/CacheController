/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ddf5b5d */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/grad/harbolad/coe758/Cache Controller/cacheController3/SDRAM_controller.vhd";
extern char *IEEE_P_1242562249;

int ieee_p_1242562249_sub_17802405650254020620_1035706684(char *, char *, char *);


static void work_a_2333980959_3212880686_p_0(char *t0)
{
    unsigned char t1;
    unsigned char t2;
    char *t3;
    unsigned char t4;
    char *t5;
    char *t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    unsigned char t10;
    unsigned char t11;
    char *t12;
    unsigned char t13;
    unsigned char t14;
    char *t15;
    char *t16;
    int t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;

LAB0:    xsi_set_current_line(51, ng0);
    t3 = (t0 + 1792U);
    t4 = xsi_signal_has_event(t3);
    if (t4 == 1)
        goto LAB8;

LAB9:    t2 = (unsigned char)0;

LAB10:    if (t2 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t3 = (t0 + 3464);
    *((int *)t3) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(52, ng0);
    t5 = (t0 + 1192U);
    t12 = *((char **)t5);
    t13 = *((unsigned char *)t12);
    t14 = (t13 == (unsigned char)2);
    if (t14 != 0)
        goto LAB11;

LAB13:    t3 = (t0 + 1192U);
    t5 = *((char **)t3);
    t1 = *((unsigned char *)t5);
    t2 = (t1 == (unsigned char)3);
    if (t2 != 0)
        goto LAB14;

LAB15:
LAB12:    goto LAB3;

LAB5:    t5 = (t0 + 1352U);
    t9 = *((char **)t5);
    t10 = *((unsigned char *)t9);
    t11 = (t10 == (unsigned char)3);
    t1 = t11;
    goto LAB7;

LAB8:    t5 = (t0 + 1832U);
    t6 = *((char **)t5);
    t7 = *((unsigned char *)t6);
    t8 = (t7 == (unsigned char)3);
    t2 = t8;
    goto LAB10;

LAB11:    xsi_set_current_line(53, ng0);
    t5 = (t0 + 1992U);
    t15 = *((char **)t5);
    t5 = (t0 + 1032U);
    t16 = *((char **)t5);
    t5 = (t0 + 6064U);
    t17 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t16, t5);
    t18 = (t17 - 65535);
    t19 = (t18 * -1);
    xsi_vhdl_check_range_of_index(65535, 0, -1, t17);
    t20 = (8U * t19);
    t21 = (0 + t20);
    t22 = (t15 + t21);
    t23 = (t0 + 3544);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    t26 = (t25 + 56U);
    t27 = *((char **)t26);
    memcpy(t27, t22, 8U);
    xsi_driver_first_trans_fast_port(t23);
    goto LAB12;

LAB14:    xsi_set_current_line(55, ng0);
    t3 = (t0 + 1512U);
    t6 = *((char **)t3);
    t3 = (t0 + 1032U);
    t9 = *((char **)t3);
    t3 = (t0 + 6064U);
    t17 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t9, t3);
    t18 = (t17 - 65535);
    t19 = (t18 * -1);
    t20 = (8U * t19);
    t21 = (0U + t20);
    t12 = (t0 + 3608);
    t15 = (t12 + 56U);
    t16 = *((char **)t15);
    t22 = (t16 + 56U);
    t23 = *((char **)t22);
    memcpy(t23, t6, 8U);
    xsi_driver_first_trans_delta(t12, t21, 8U, 0LL);
    goto LAB12;

}


extern void work_a_2333980959_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2333980959_3212880686_p_0};
	xsi_register_didat("work_a_2333980959_3212880686", "isim/project_test_bench_isim_beh.exe.sim/work/a_2333980959_3212880686.didat");
	xsi_register_executes(pe);
}
